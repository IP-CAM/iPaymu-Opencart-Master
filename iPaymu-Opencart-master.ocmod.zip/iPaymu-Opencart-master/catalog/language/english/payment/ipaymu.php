<?php
// Text
$_['text_title'] = 'iPaymu';
$_['currency_support'] = "iPaymu only support IDR, please contact administrator";
$_['currency_convert'] = "Your Order will convert into IDR, please confirm to continue.";
?>